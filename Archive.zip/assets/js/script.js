Vue.component('MoviePosters', {
    props: ['movies'],
    template: `
<div class="container">
  <div class="row">
    <div class="col" v-for="(movie, index) in movies" :key="index" v-if="index < 10">
      <div class="card" style="width: 18rem;">
        <img class="card-img-top" :src="movie.poster" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">{{movie.title}}</h5>
        </div>
      </div>
    </div>
  </div>
</div>
`,
})



new Vue({
    el: '#app',
    data: {
        categories: [],
        movies: []
    },
    mounted() {
        this.getAllCategories();
    },
    methods: {
        getAllCategories() {
            let url = 'https://api.themoviedb.org/3/genre/movie/list'
            axios
                .get(url, {
                    params: {
                        api_key: 'b73ad2eaa4501675efa5fdf8edb150d9'
                    }
                })
                .then(response => {
                    this.categories = response.data.genres;
                })
        },
        getMoviesByCategory(category) {
          console.log(category)
          this.movies = []; 
          const url = 'https://api.themoviedb.org/3/discover/movie';
          axios
              .get(url, {
                  params: {
                      api_key: 'b73ad2eaa4501675efa5fdf8edb150d9',
                      with_genres: category.value,
                      sort_by: 'vote_count.desc',
                      include_adult: false,
                      include_video: false,
                      language: 'fr-FR',
                      page: 1,
                      with_original_language: 'fr',
                  }
              })
              .then(response => {
                  this.movies = response.data.results.slice(0, 10).map(movie => ({
                      poster: 'https://image.tmdb.org/t/p/w500' + movie.poster_path,
                      title: movie.title,
                      description: movie.overview
                  }));
              })
              .catch(error => {
                  console.error('Error fetching movies:', error);
              });
      },
    }
})
